package com.definition;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Repository {
	
	

	@FindBy(css = "[autocomplete*='username']")
    public static WebElement user;

    @FindBy(xpath = "//input[@type='password']")
    public static WebElement pswrd;

	@FindBy(xpath = "//*[text()='Submit']")
    public static WebElement submit;
	
     @FindBy(linkText = "Lowest price")
	 public static WebElement orderby1;
	
	@FindBy(linkText =   "Advertisements")
	public static WebElement adv;
	
	@FindBy(css = "[class*='btn d-flex justify']")
    public static WebElement showadvertisements;
	
	
	@FindBy(xpath = "//*[text()='Show categories']")
    public static WebElement showcategories;
	
	@FindBy(css = "[class*='form-control text-left']")
	public static WebElement orderby;
	
	@FindBy(css = "[class*='form-control w']")
	public static WebElement keyword;
	
	
	@FindBy(xpath = "//a[contains(text(),'Community')]")
	public static WebElement community;
	
	@FindBy(xpath = "(//a[@class='category-footer'])[1]")
	public static WebElement showall;
	
	@FindBy(xpath = "//script[@type='text/javascript']")
	public static WebElement activity;
	
	@FindBy(xpath ="//*[text()='Marketplace']")
	public static WebElement marketplace;
	
	@FindBy(xpath = "//div[text()='My vouchers']")
	public static WebElement myvouchers;
	
	@FindBy(xpath = "//div[text()='Print']")
	public static WebElement printbtn;
	
	@FindBy(xpath = "//div[text()='Buy vouchers']")
	public static WebElement buyvouchers;
	
	@FindBy(xpath = "//input[@type='number']")
	public static WebElement noofvouchers;
	
	@FindBy(xpath = "//input[@placeholder='0,00']")
	public static WebElement amnt;
	
	@FindBy(xpath = "//label[text()=' I will use the voucher myself (only personal use is allowed) ']")
	public static WebElement label1;
	
	@FindBy(xpath = "//label[@for='id_30_true']")
	public static WebElement label2;
	
	@FindBy(xpath = "//span[text()='Next']")
	public static WebElement next;
	
	@FindBy(xpath = "//span[text()='Confirm']")
	public static WebElement confirm;
	
	@FindBy(linkText = "Restaurant voucher")
	public static WebElement printvoucher;
	
	@FindBy(xpath = "(//div[@class='avatar-container'])[1]")
	public static WebElement giftvoucher;
}
