package com.runnerclass;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(

features={"Feature file/Customize advertisement/CustomizeADV.feature"},
glue= {"com.definition"}


)

public class AdvRunner extends AbstractTestNGCucumberTests {

}
