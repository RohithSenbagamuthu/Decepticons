package com.definition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.github.bonigarcia.wdm.WebDriverManager;
import okhttp3.internal.http2.Header;

public class Stepdef1 {
	
 WebDriver driver;
	@Given("User should click on advertisements menu")
	public void user_should_click_on_advertisements_menu() throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		 WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://demo.cyclos.org/ui/home");
		driver.manage().window().maximize();
		driver.findElement(By.cssSelector("[id*='login-link']")).click();
		PageFactory.initElements(driver, Repository.class);
		Repository.user.sendKeys("demo");
		Repository.pswrd.sendKeys("1234");
		Repository.submit.click();
		Thread.sleep(3000);
		Repository.marketplace.click();
		Thread.sleep(6000);
		Repository.adv.click();
		ExtentCucumberAdapter.addTestStepLog(Status.PASS + "adv Clicked");
}
	@Given("User should click on show advertisements")
	public void user_should_click_on_show_advertisements() throws InterruptedException {
		//PageFactory.initElements(driver, Repository.class);
		Thread.sleep(3000);
		Repository.showadvertisements.click();

	    
	} 
	@Given("User should click on Order by")
	public void user_should_click_on_order_by() {
	//	PageFactory.initElements(driver, Repository.class);
		Repository.orderby.click();
	}
	@Then("User should select required choice from dropdown.")
	public void user_should_select_required_choice_from_dropdown() throws InterruptedException {
		Thread.sleep(6000);
	    Repository.orderby1.click();
	    
	}

	@Then("User should locate and click keyword text field and send text")
	public void user_should_locate_and_click_keyword_text_field_and_send_text() {
	//	PageFactory.initElements(driver, Repository.class);
		
		Repository.keyword.sendKeys("food");
	//	Repository.keyword.clear();
	//	driver.navigate().back();
	}


	@Given("User should select on the community menu")
	public void user_should_select_on_the_community_menu() throws InterruptedException {
	//	PageFactory.initElements(driver, Repository.class);
		Thread.sleep(3000);
		Repository.showcategories.click();
		Repository.community.click();
	  
	}
	@Then("User should select needed advertisement in community menu")
	public void user_should_select_needed_advertisement_in_community_menu() throws InterruptedException {
	   Thread.sleep(3000);
	   WebElement food = driver.findElement(By.xpath("(//div[@class='card-text'])[1]"));
	 
	   food.click();
	   driver.navigate().back();
	}
 	@Given("user should click on the advertisement menu")
	public void user_should_click_on_the_advertisement_menu() {
	//	PageFactory.initElements(driver, Repository.class);
		Repository.showcategories.click();	   
	}

	@Given("user should click on the {string} option from community field")
	public void user_should_click_on_the_option_from_community_field(String string) {
	Repository.showall.click();

	}
	@Given("user should click {string} from the community list")
	public void user_should_click_from_the_community_list(String string) {
	 Repository.activity.click();

	}
	@Then("user should select needed advertisement from activity list")
	public void user_should_select_needed_advertisement_from_activity_list() {
		  WebElement food1 = driver.findElement(By.xpath("(//div[@class='card-text'])[3]"));
		   food1.click();
		   driver.navigate().back();
	}
	@Given("User should locate and select on the required voucher from the list")
	public void User_should_locate_and_select_on_the_required_voucher_from_the_list() {
		Repository.myvouchers.click();
		Repository.printvoucher.click();
	}
	@Then("user should locate {string} icon displayed right side corner of marketplace banner and click")
	public void user_should_locate_icon_displayed_right_side_corner_of_marketplace_banner_and_click(String string) throws InterruptedException {
		    Thread.sleep(3000);
            Repository.printbtn.click();
       /*     String Expected = "Member account";

            String Actual = Repository.check.getpdf();

            System.out.println(Actual);

            Assert.assertEquals(Actual, Expected);  */
           
	} 
	@Given("User should locate and click on the {string} icon")
	public void user_should_locate_and_click_on_the_icon(String string) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(Repository.myvouchers));
		 Repository.myvouchers.click();
		 wait.until(ExpectedConditions.visibilityOf(Repository.buyvouchers));
	      Repository.buyvouchers.click();
	}

	@Given("user should locate and click any one of the vocher displayed in Buy and email voucher banner.")
	public void user_should_locate_and_click_any_one_of_the_vocher_displayed_in_buy_and_email_voucher_banner() throws InterruptedException {
		Thread.sleep(3000);
		Repository.giftvoucher.click();
	}

	@Given("user should locate and enter the no.of.vouchers")
	public void user_should_locate_and_enter_the_no_of_vouchers() {
		Repository.noofvouchers.sendKeys("1");
	}

	@Given("user should locate and enter the valid amount")
	public void user_should_locate_and_enter_the_valid_amount() {
		Repository.amnt.sendKeys("200");
	}

	@Given("user should locate and click valid {string} option")
	public void user_should_locate_and_click_valid_option(String string) throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(3000);
		Repository.label2.click();
	}

	@Given("user should locate and click {string} button1.")
	public void user_should_locate_and_click_button1(String string) throws InterruptedException {
		Thread.sleep(3000);
		Repository.next.click();
	}

	@Then("user should locate and click {string} button.")
	public void user_should_locate_and_click_button(String string) {
		Repository.submit.click();
		
		
		
	}

	






}
