package com.repo;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class messageRepository {
	@FindBy (xpath="//div[text()='Messages']")
	public static WebElement message;
	
	@FindBy (xpath="//div[@class='heading-actions-plain-buttons']")
	public static WebElement newMessage;
	
	@FindBy(xpath="(//button[@type='button'])[3]")
	public static WebElement sendTo;
	
	@FindBy(linkText="User")
	public static WebElement user;
	
	@FindBy(xpath="//input[@placeholder='Type to search']")
	public static WebElement toUser;//send keys as a
	
	@FindBy(xpath="//div[@id=\"dropdown-menu-id_54\"]//a")
	public static WebElement toUserList;
	
	@FindBy(xpath="(//div[@class='d-flex label-value-value']//input)[2]")
	public static WebElement subject;
	
	@FindBy(className="editor")
	public static WebElement content;

	@FindBy(linkText="Send")
	public static WebElement sendButton;
	
	//for Administration
	@FindBy(xpath="//a[@class='nav-item active']//div[1]")
	public static WebElement message2;
	
	@FindBy(linkText="Administration")
	public static WebElement administrator;
	
	@FindBy(xpath="//div[@class='dropdown-menu show']//a")
	public static WebElement contentList;//select any one of the content
	
	@FindBy(xpath="//div[@class='toolbar']/following-sibling::div[1]")
	public static WebElement content2;
	//inbox
	@FindBy(xpath="//input[@value='inbox']")
	public static WebElement inbox;
	
	//sent button
	@FindBy(css="input[value='sent']")
	public static WebElement sentButton;
	
	//trash button
	@FindBy(css="input[value='trash']")
	public static WebElement trash;
	
	@FindBy (xpath="//div[@class='w-100 mw-100 text-truncate pr-3']")
	public static WebElement from;
	
	@FindBy(xpath="//a[text()='All']")
	public static WebElement All;
	
	@FindBy (linkText=" User")
	public static WebElement user1;
	
	@FindBy (linkText=" Administration ")
	public static WebElement  administration;
	
	@FindBy(css="input.form-control.w-100")
	public static WebElement keywords;
	
	@FindBy(xpath="//input[@placeholder='Type to search']")
	public static WebElement userName;
	
}
