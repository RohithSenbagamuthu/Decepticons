package com.repo;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class marketPlaceRepository {
	@FindBy(xpath="//div[text()='Marketplace']")
	public static WebElement marketPlace;
	
	//send a richtext
	@FindBy(linkText="My advertisements")
	public static WebElement myadd;
	
	@FindBy(xpath="(//button[@type='button']//div)[1]")
	public static WebElement addNew;
	
	@FindBy(xpath="//input[contains(@class,'form-control w-100')]")
	public static WebElement name;
	
	@FindBy(xpath="//div[@class='dropdown-menu show']//a")
	public static WebElement categoryList;//list of the category
	
	//publication period
	@FindBy(xpath="(//input[contains(@class,'form-control flex-grow-1')])[1]")
	public static WebElement fromDate;
	
	@FindBy(xpath="(//input[contains(@class,'form-control flex-grow-1')])[2]")
	public static WebElement toDate;
	
	//enter rich text
	@FindBy(className="editor")
	public static WebElement desc;
	
	@FindBy(linkText="Save")
	public static WebElement saveBtn;
	
	//Address
	@FindBy(xpath="(//button[contains(@class,'form-control text-left')])[2]")
	public static WebElement address;
	
	//to customize favorite filters
	@FindBy(xpath="//div[text()='Advertisements']")
	public static WebElement Advertisement;
	
	@FindBy(css="input.form-control.w-100")
	public static WebElement keyword;
	
	@FindBy(xpath="(//label[@class='custom-control-label'])[1]")
	public static WebElement favorite;
	
	@FindBy(xpath="(//input[@placeholder='0,00'])[1]")
	public static WebElement minPrice;
	
	@FindBy(xpath="(//input[@placeholder='0,00'])[2]")
	public static WebElement maxPrice;
	

}
