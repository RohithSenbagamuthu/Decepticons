package com.repo;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class alertAndLoggingRepository {
	@FindBy(linkText="Marketplace")
	public static WebElement marketPlace;
	
	@FindBy(xpath="//div[@class='nav-item-text'])[2])")
	public static WebElement add;
	
	@FindBy(xpath="//span[text()='Show advertisements']")
	public static WebElement showAdd;
	
	@FindBy(xpath="(//div[@class='avatar-container full-size'])[1]")
	public static WebElement product;
	
	@FindBy(xpath="(//button[@type='button']//div)[3]")
	public static WebElement askMeQus;

}
